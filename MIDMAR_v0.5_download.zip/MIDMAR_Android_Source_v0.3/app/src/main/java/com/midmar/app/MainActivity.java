package com.midmar.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import android.content.Intent;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.net.URL;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private WebView web;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("midmar", MODE_PRIVATE);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Midmar");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private String readAsset(String name) throws Exception {
        InputStream in = getAssets().open(name);
        BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) b.append(line).append('\n');
        r.close();
        return b.toString();
    }

    private JSONArray parseM3U(String raw, String sourceName) throws Exception {
        JSONArray out = new JSONArray();
        String[] lines = raw.split("\\r?\\n");
        String title = null, group = "قنوات مضافة";
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.startsWith("#EXTINF")) {
                int comma = line.lastIndexOf(',');
                title = comma >= 0 ? line.substring(comma + 1).trim() : "قناة بدون اسم";
                int g = line.indexOf("group-title=");
                if (g >= 0) {
                    int q1 = line.indexOf('"', g), q2 = q1 >= 0 ? line.indexOf('"', q1 + 1) : -1;
                    if (q1 >= 0 && q2 > q1) group = line.substring(q1 + 1, q2);
                }
            } else if (!line.isEmpty() && !line.startsWith("#") && title != null) {
                if (line.startsWith("https://")) {
                    JSONObject item = new JSONObject();
                    item.put("name", title);
                    item.put("group", group);
                    item.put("url", line);
                    item.put("source", sourceName);
                    out.put(item);
                }
                title = null;
            }
        }
        return out;
    }

    private class Bridge {
        @JavascriptInterface public String getEmbeddedPlaylist() {
            try { return parseM3U(readAsset("channels.m3u"), "MIDMAR").toString(); }
            catch (Exception e) { return "[]"; }
        }

        @JavascriptInterface public String getSavedPlaylists() {
            return prefs.getString("playlists", "[]");
        }

        @JavascriptInterface public void addPlaylist(String playlistUrl) {
            if (playlistUrl == null || !playlistUrl.startsWith("https://")) {
                handler.post(() -> Toast.makeText(MainActivity.this, "استخدم رابط HTTPS لقائمة تملك حق استخدامها", Toast.LENGTH_LONG).show());
                return;
            }
            new Thread(() -> {
                HttpURLConnection c = null;
                try {
                    URL u = new URL(playlistUrl);
                    c = (HttpURLConnection) u.openConnection();
                    c.setConnectTimeout(10000);
                    c.setReadTimeout(15000);
                    c.setRequestProperty("User-Agent", "MIDMAR/0.2");
                    if (c.getResponseCode() < 200 || c.getResponseCode() >= 300) throw new Exception("HTTP " + c.getResponseCode());
                    BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder b = new StringBuilder(); String line;
                    while ((line = r.readLine()) != null && b.length() < 2_000_000) b.append(line).append('\n');
                    r.close();
                    JSONArray parsed = parseM3U(b.toString(), playlistUrl);
                    if (parsed.length() == 0) throw new Exception("لم يتم العثور على روابط HTTPS صالحة");
                    JSONArray all = new JSONArray(prefs.getString("playlists", "[]"));
                    for (int i=0;i<parsed.length();i++) all.put(parsed.getJSONObject(i));
                    prefs.edit().putString("playlists", all.toString()).apply();
                    handler.post(() -> {
                        web.evaluateJavascript("playlistAdded()", null);
                        Toast.makeText(MainActivity.this, "تمت إضافة " + parsed.length() + " قناة", Toast.LENGTH_LONG).show();
                    });
                } catch (Exception e) {
                    handler.post(() -> Toast.makeText(MainActivity.this, "تعذر تحميل القائمة. تحقق من الرابط والترخيص.", Toast.LENGTH_LONG).show());
                } finally { if (c != null) c.disconnect(); }
            }).start();
        }

        @JavascriptInterface public void play(String url, String name) {
            if (url == null || !url.startsWith("https://")) {
                handler.post(() -> Toast.makeText(MainActivity.this, "الرابط غير صالح أو غير آمن", Toast.LENGTH_LONG).show());
                return;
            }
            handler.post(() -> {
                Intent i = new Intent(MainActivity.this, PlayerActivity.class);
                i.putExtra("url", url);
                i.putExtra("name", name == null ? "MIDMAR" : name);
                startActivity(i);
            });
        }
    }
}
